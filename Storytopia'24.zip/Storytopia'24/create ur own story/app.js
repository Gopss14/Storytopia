const express = require('express');
const mongoose = require('mongoose');
const router = express.Router();

 // Define the story schema using Mongoose
 const storySchema = new mongoose.Schema({
    title: {
        type: String,
        required: true
    },
    genre: {
        type: String,
        required: true
    },
    content: {
        type: String,
        required: true
    },
    createdAt: {
        type: Date,
        default: Date.now
    }
});

// // Create a Story model
const Story = mongoose.model('Story', storySchema);

// Route to create a new story
router.post('/', async (req, res) => {
    try {
        const { title, genre, content } = req.body;

        // Create a new story object
        const newStory = new Story({
            title,
            genre,
            content
        });

        // Save the story to the database
        await newStory.save();
        res.status(201).json({ message: 'Story created successfully', story: newStory });
    } catch (err) {
        res.status(500).json({ message: 'Error creating story', error: err });
    }
});

module.exports = router;
